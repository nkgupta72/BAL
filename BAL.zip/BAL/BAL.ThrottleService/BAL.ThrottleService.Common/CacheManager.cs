﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.ThrottleService.Common
{
    public static class CacheManager
    {
        static public List<ThrottledUser> ThrottledUsers;

        /// <summary>
        /// CachedUserRequests
        /// </summary>
        /// <returns></returns>
        private static List<ThrottledUser> GetUserRequests()
        {
            return ThrottledUsers;
        }

        /// <summary>
        /// AddCacheUserRequest
        /// </summary>
        /// <returns></returns>
        public static bool AddUserRequest(System.Guid userId, DateTime requestTime)
        {
            var success = true;

            if (ThrottledUsers == null)
                ThrottledUsers = new List<ThrottledUser>();

            try
            {
                var ThrottledUser = new ThrottledUser(userId, requestTime);
                ThrottledUsers.Add(ThrottledUser);
            }
            catch (Exception ex)
            {
                success = false;
                // TBD: Add stacktrace log/notification
            }
            finally { }
            return success;
        }

    }
}

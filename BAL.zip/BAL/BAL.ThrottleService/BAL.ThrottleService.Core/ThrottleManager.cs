﻿using BAL.ThrottleService.Common;
using BAL.ThrottleService.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.ThrottleService.Core
{
    /// <summary>
    /// ThrottleManager
    /// </summary>
    public class ThrottleManager : IThrottle
    {
        /// <summary>
        /// IsUserThrottled:
        /// Return true iff the user (identified by the given GUID) has made more than 100 requests within 60 minutes of 
        //  specified request time.In all other cases, the method return false
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="requestTime"></param>
        /// <returns></returns>
        public bool IsUserThrottled(Guid userId, DateTime requestTime)
        {
            bool result = false;

            // Get the cached throttled requests by users
            var tus = CacheManager.ThrottledUsers;

            if (tus != null)
            {

                // Find all the requests made by a UserId
                var userRequests = tus.Where(t => t.UserId == userId).ToList();

                // Count all the requests since last 1 hr.
                int count = CountRequestsInLastHour(userRequests, requestTime);

                // result
                result = (count >= 100) ? true : false;
            }

            return result;
        }

        /// <summary>
        /// CountRequestsInLastHour
        /// </summary>
        /// <param name="userRequests"></param>
        /// <param name="requestTime"></param>
        /// <returns></returns>
        private int CountRequestsInLastHour(List<ThrottledUser> userRequests, DateTime requestTime)
        {
            var count = 0;

            DateTime dateTimeOneHourBack = requestTime.AddHours(-1);

            var requests = userRequests.Where(u => u.RequestTime >= dateTimeOneHourBack
                                                && u.RequestTime < requestTime).ToList();

            count = requests.Count();

            return count;
        }
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BAL.ThrottleService.Core;
using BAL.ThrottleService.Common;

namespace BAL.ThrottleService.UnitTests
{
    /// <summary>
    /// Unit tests
    /// </summary>
    [TestClass]
    public class TrottleUnitTests
    {
        ThrottleManager _tm = new ThrottleManager();

        /// <summary>
        /// User A has made 99 requests in the past 24 hours. Only 9 of these requests came in the last hour. 
        /// When the method is invoked for the next request, it should return false
        /// </summary>
        [TestMethod]
        public void Should_Return_False_With_9_Requests_Last_Hour()
        {
            // Arrange
            // Add 99 requests 
            var userA = new Guid("{92fec13c-e799-4227-aec7-ace7bf7dd272}");
            var dt = DateTime.Now;

            for (int i = 0; i < 99; i++)
            {
                if (i < 90)
                {
                    CacheManager.AddUserRequest(userA, dt.AddMinutes(-i -120)); // 90 requests before 2 hr
                }
                else //if (i > 90)
                {
                    CacheManager.AddUserRequest(userA, dt.AddMinutes(90 - i )); // -90+45 = req made -45 Mins prior
                }
            }

            var users = CacheManager.ThrottledUsers;

            // Act
            var result = _tm.IsUserThrottled(new Guid("{92fec13c-e799-4227-aec7-ace7bf7dd272}"), DateTime.Now);

            // Assert
            Assert.IsFalse(result);
        }


        /// <summary>
        /// User B has made 100 requests between 6:50 and 7:00. 
        /// The method invocation for a request at 7:05 should return true
        /// </summary>
        [TestMethod]
        public void Should_Return_True_With_100_Requests()
        {
            // Arrange
            // Add 100 requests 
            var userB = new Guid("{92fec13c-e799-4227-aec7-ace7bf7dd272}");
            var dt = new DateTime(2017, 9, 10, 6, 50, 0);

            for (int i = 0; i < 100; i++)
            {
                CacheManager.AddUserRequest(userB, dt.AddSeconds(1)); // 100 requests 
            }

            var users = CacheManager.ThrottledUsers;

            // Act
            var dtNewReq = new DateTime(2017, 9, 10, 7, 5, 0);
            var result = _tm.IsUserThrottled(userB, dtNewReq);

            // Assert
            Assert.IsTrue(result);
        }


        /// <summary>
        /// User C has made 1 request as minute for the last 90 minutes. 
        /// As long as this rate continues, the method should return false 
        /// for every invocation
        /// </summary>
        [TestMethod]
        public void Should_Return_False_With_1Min_Interval_Request()
        {
            // Arrange
            var userC = new Guid("{92fec13c-e799-4227-aec7-ace7bf7dd272}");
            var dt = new DateTime(2017, 9, 10, 6, 30, 0);

            for (int i = 0; i < 90; i++)
            {
                CacheManager.AddUserRequest(userC, dt.AddMinutes(1));
            }

            var users = CacheManager.ThrottledUsers;

            // Act: Request after 90 mins
            var dtNewReq = new DateTime(2017, 9, 10, 8, 01, 0);

            var result = _tm.IsUserThrottled(userC, dtNewReq);

            // Assert
            Assert.IsFalse(result);
        }

        /// <summary>
        /// User D makes requests at 10:00:00 and continuing at a rate of 1 every 30 seconds for 50 minutes, 
        // then continues making requests at a rate of 1 every 60 seconds.The request at 10:49:30 should return false.
        // The request made at 10:50:00 should return true. 
        // The request made at 10:51:00 should return false: TBD. 
        // The request made at 10:52:00 should return false: TBD.
        /// </summary>
        [TestMethod]
        public void Should_Return_TFF()
        {
            // Arrange
            var userD = new Guid("{92fec13c-e799-4227-aec7-ace7bf7dd272}");
            var dt = new DateTime(2017, 9, 10, 10, 0, 0);

            // Requests @ 30 secs: till 10:50
            for (int i = 0; i < 200; i++)
            {
                if ( i < 100)
                    CacheManager.AddUserRequest(userD, dt.AddSeconds(30));
                else
                    CacheManager.AddUserRequest(userD, dt.AddSeconds(60));

                // Request made @ 10:49:30
                if (i == 98)
                {
                    // Act
                    var result = _tm.IsUserThrottled(userD, new DateTime(2017, 9, 10, 10, 49, 30));

                    // Assert
                    Assert.IsFalse(result);
                }

                // Request made @ 10:50:00
                if (i == 99)
                {
                    // Act
                    var result = _tm.IsUserThrottled(userD, new DateTime(2017, 9, 10, 10, 50, 0));

                    // Assert
                    Assert.IsTrue(result);
                }

                // Request made @ 10:51:00
                if (i == 100)
                {
                    // Act
                    var result = _tm.IsUserThrottled(userD, new DateTime(2017, 9, 10, 10, 51, 0));

                    // Assert
                    Assert.IsFalse(result);
                }

                // Request made @ 10:52:00
                if (i == 101)
                {
                    // Act
                    var result = _tm.IsUserThrottled(userD, new DateTime(2017, 9, 10, 10, 52, 0));

                    // Assert
                    Assert.IsFalse(result);
                }
            }
        }
    }
}

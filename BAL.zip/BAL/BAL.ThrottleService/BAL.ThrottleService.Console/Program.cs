﻿using BAL.ThrottleService.Common;
using BAL.ThrottleService.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.ThrottleService.Console
{
    class Program
    {
        private static List<ThrottledUser> _tus;

        static void Main(string[] args)
        {
            var userId = new Guid("{92fec13c-e799-4227-aec7-ace7bf7dd272}");

            var result = MakeUserRequest(userId, DateTime.Now);

            _tus = CacheManager.ThrottledUsers;

            ////
            foreach (var tu in _tus)
            {
                var result2 = MakeUserRequest(tu.UserId, tu.RequestTime);

                if (result2 == true)
                {
                    System.Console.WriteLine("User has already made 100 requests in last one hr");
                }
            }

            System.Console.ReadLine();
        }
        
        /// <summary>
        /// MakeUserRequest
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="requestTime"></param>
        /// <returns></returns>
        private static bool MakeUserRequest(System.Guid userId, DateTime requestTime)
        {
            System.Console.WriteLine("MakeUserRequest called");

            ThrottleManager tm = new ThrottleManager();
            var result = tm.IsUserThrottled(userId, requestTime);

            return result;
        }
    }
}

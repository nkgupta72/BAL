﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.ThrottleService.Interface
{
    /// <summary>
    /// IThrottle interface
    /// </summary>
    public interface IThrottle
    {
        bool IsUserThrottled(System.Guid userId, DateTime requestTime);
    }
}
